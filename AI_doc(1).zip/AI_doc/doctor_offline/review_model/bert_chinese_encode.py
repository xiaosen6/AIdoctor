import torch
import torch.nn as nn


from transformers import AutoTokenizer, AutoModelForMaskedLM

tokenizer = AutoTokenizer.from_pretrained("/home/bert/bert-base-chinese")

model = AutoModelForMaskedLM.from_pretrained("/home/bert/bert-base-chinese")

def get_bert_encode_for_single(text):
    """
    使用bert-base-chinese模型对文本进行编码
    :param text:  输入的文本
    :return: 编码后的张量
    """
    # 公国tokenizer对文本进行编号
    indexed_tokens = tokenizer.encode(text)[1: -1]
    # print('text 编号: ',indexed_tokens, type(indexed_tokens))
    # [101, 872, 1962, 8024, 4886, 2456, 5664, 102]
    # 把列表转成张量
    tokens_tensor = torch.LongTensor([indexed_tokens])

    # 不自动进行梯度计算
    with torch.no_grad():
        output = model(tokens_tensor)
        # print('model的输出: ', output)

    return output[0]


if __name__ == '__main__':
    text = "你好，福建舰"
    outputs = get_bert_encode_for_single(text)
    # print('text编码:', outputs)
