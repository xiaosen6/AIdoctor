import requests

# # 定义请求url和传入的data
# url = "http://192.168.1.53:5000/v1/main_serve/"
# data = {"uid":"222", "text": "腹胀"}
#
# # 向服务发送post请求
# res = requests.post(url, data=data)
# # 打印返回的结果
# print(res.text)



url = "http://192.168.1.53:5001/v1/recognition/"
data = {"text1":"水痘水痘后第七天脸上色素严重", "text2": "五险一金会下调吗"}
res = requests.post(url, data=data)

print("预测样本：", data["text1"], "|", data["text2"])
print("预测结果：", res.text)



